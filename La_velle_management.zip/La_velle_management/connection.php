<?php 
$con=mysqli_connect("localhost","root","","la_velle") or die('DATABASE connection failed');

?>